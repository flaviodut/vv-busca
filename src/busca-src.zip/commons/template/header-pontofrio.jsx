import React from 'react'
import styled from 'styled-components'

import Row from '../layout/row'
import Grid from '../layout/grid'

import LogoPontofrio from '../../commons/assets/cb/logo-pontofrio.png'

export default class Header extends React.Component {
  render() {
    
    return (
    )
  }
}